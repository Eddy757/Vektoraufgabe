﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace VektorProjekt
{
    class Program
    {
        
        static void Main(string[] args)
        {

            Vektor vektor1 = new Vektor(1.23456, 2, 3);
            Vektor vektor2 = new Vektor(-5.123456, 2, 3);

            Console.WriteLine("Kreuzrpodukt: Vektor1 X Vektor2");
            VektorFunktionen.AusgabeBildschirm(VektorFunktionen.Kreuzprodukt(vektor1, vektor2));

            Console.WriteLine("Skalarprodukt: Vektor1 * Vektor2");
            Console.WriteLine(VektorFunktionen.Skalarprodukt(vektor1, vektor2));
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Addition: Vektor1 + Vektor2");
            VektorFunktionen.AusgabeBildschirm(VektorFunktionen.Addition(vektor1, vektor2));

            Console.WriteLine("Winkel zw. Vektor1 und Vektor2");
            Console.WriteLine(VektorFunktionen.WinkelZw2Vektoren(vektor1, vektor2) + " grad");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Laenge Vektor1");
            Console.WriteLine(VektorFunktionen.LaengeBerechnen(vektor1));
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Multiplikation mit Skalar: Vektor1 * Skalar");
            VektorFunktionen.AusgabeBildschirm(VektorFunktionen.MultiplMitSkalar(vektor1, 5));

            Console.WriteLine("Division durch Skalar: Vektor2 / Skalar");
            VektorFunktionen.AusgabeBildschirm(VektorFunktionen.DivisionDurchSkalar(vektor2, 4));

            Console.WriteLine("Division durch Skalar = 0 : Vektor2 / Skalar");
            VektorFunktionen.AusgabeBildschirm(VektorFunktionen.DivisionDurchSkalar(vektor2, 0));

            Vektor vektor3 = new Vektor(5, 7, 10);
            Vektor vektor4 = new Vektor(5, 7, 10);

            Console.WriteLine("Ueberpruefung, ob die Werte der Vektoren gleich sind");
            VektorFunktionen.VektorenWertgleich(vektor3, vektor4);
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Vektor2 invertieren");
            VektorFunktionen.AusgabeBildschirm(VektorFunktionen.Invertieren(vektor2));
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            Console.ReadLine();
        }
    }
}
