﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using VektorBibliothekProjekt;

namespace VektorFunktionenBibliothekTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethodInvertieren()
        {
            Vektor[] vektoren = new Vektor[3];
            vektoren[0] = new Vektor(1.55, 2, 3);
            vektoren[1] = new Vektor(0, 0, 0);
            vektoren[2] = new Vektor(-1, 2.754, -3);

            Vektor[] vektorenInvertiert = new Vektor[3];
            vektorenInvertiert[0] = new Vektor(-1.55, -2, -3);
            vektorenInvertiert[1] = new Vektor(0, 0, 0);
            vektorenInvertiert[2] = new Vektor(1, -2.754, 3);

            for (int i = 0; i < vektoren.Length; i++)
            {
                Vektor vektorInvert = VektorFunktionen.Invertieren(vektoren[i]);
                bool result = VektorFunktionen.VektorenWertgleich(vektorInvert, vektorenInvertiert[i]);
                String word = "xyz";

                Assert.IsTrue(result, String.Format("Expected for '{0}': true; Actual: {1}", word, result));
            }
        }


        [TestMethod]
        public void TestMethodAddition()
        {
            Vektor[] vektorenSummand1 = new Vektor[3];
            vektorenSummand1[0] = new Vektor(1.5, 2, 3);
            vektorenSummand1[1] = new Vektor(0, 0, 0);
            vektorenSummand1[2] = new Vektor(-1, 2, -3);
            
            Vektor[] vektorenSummand2 = new Vektor[3];
            vektorenSummand2[0] = new Vektor(-5, 2, 3);
            vektorenSummand2[1] = new Vektor(4, -1.678, -5);
            vektorenSummand2[2] = new Vektor(1, -2, 3);

            Vektor[] vektorenSumme = new Vektor[3];
            vektorenSumme[0] = new Vektor(-3.5, 4, 6);
            vektorenSumme[1] = new Vektor(4, -1.678, -5);
            vektorenSumme[2] = new Vektor(0, 0, 0);
            
            for (int i = 0; i < vektorenSummand1.Length; i++)
            {
                Vektor vektorSum = VektorFunktionen.Addition(vektorenSummand1[i], vektorenSummand2[i]);
                Console.WriteLine("hallo");
                Console.WriteLine("X: " + vektorSum.XKoord + "Y: " + vektorSum.YKoord + "Z: " + vektorSum.ZKoord);
                bool result = VektorFunktionen.VektorenWertgleich(vektorSum, vektorenSumme[i]);
                Console.WriteLine(result);
                String word = "xyz";
                Assert.IsTrue(result, String.Format("Expected for '{0}': true; Actual: {1}", word, result));
            }
            
        }


        [TestMethod]
        public void TestMethodSubtraktion()
        {
            Vektor[] vektorenMinuend = new Vektor[3];
            vektorenMinuend[0] = new Vektor(1, 2, 3);
            vektorenMinuend[1] = new Vektor(0, 0, 0);
            vektorenMinuend[2] = new Vektor(-1, 2, -3);

            Vektor[] vektorenSubtrahend = new Vektor[3];
            vektorenSubtrahend[0] = new Vektor(-5.5, 2, 3);
            vektorenSubtrahend[1] = new Vektor(4, -1.786, -5);
            vektorenSubtrahend[2] = new Vektor(1, -2, 3);

            Vektor[] vektorenDifferenz = new Vektor[3];
            vektorenDifferenz[0] = new Vektor(6.5, 0, 0);
            vektorenDifferenz[1] = new Vektor(-4, 1.786, 5);
            vektorenDifferenz[2] = new Vektor(-2, 4, -6);

            for (int i = 0; i < vektorenMinuend.Length; i++)
            {
                Vektor vektorDiff = VektorFunktionen.Subtraktion(vektorenMinuend[i], vektorenSubtrahend[i]);
                bool result = VektorFunktionen.VektorenWertgleich(vektorDiff, vektorenDifferenz[i]);
                String word = "xyz";
                Assert.IsTrue(result, String.Format("Expected for '{0}': true; Actual: {1}", word, result));
            }
        }

        [TestMethod]
        public void TestMethodMultiplMitSkalar()
        {
            Vektor[] vektoren = new Vektor[3];
            vektoren[0] = new Vektor(1.6453, 2, 3);
            vektoren[1] = new Vektor(0, -5, 0);
            vektoren[2] = new Vektor(-1, 2, -3);

            double[] skalar = new double[3] { 3.546, -5, 0 };

            Vektor[] vektorenErgebnis = new Vektor[3];
            vektorenErgebnis[0] = new Vektor(5.8342338, 7.092, 10.638);
            vektorenErgebnis[1] = new Vektor(0, 25, 0);
            vektorenErgebnis[2] = new Vektor(0, 0, 0);

            for (int i = 0; i < vektoren.Length; i++)
            {
                Vektor vektorMultMitSkalar = VektorFunktionen.MultiplMitSkalar(vektoren[i], skalar[i]);
                bool result = (String.Format("{0:f5}", vektorMultMitSkalar.XKoord) == String.Format("{0:f5}", vektorenErgebnis[i].XKoord)) 
                                && (String.Format("{0:f5}", vektorMultMitSkalar.YKoord) == String.Format("{0:f5}", vektorenErgebnis[i].YKoord)) 
                                && (String.Format("{0:f5}", vektorMultMitSkalar.ZKoord) == String.Format("{0:f5}", vektorenErgebnis[i].ZKoord));
                String word = "xyz";
                Assert.IsTrue(result, String.Format("Expected for '{0}': true; Actual: {1}", word, result));
            }
        }

        [TestMethod]
        public void TestMethodDivisionDurchSkalar()
        {

            Vektor[] vektoren = new Vektor[3];
            vektoren[0] = new Vektor(1, 2, 3);
            vektoren[1] = new Vektor(0, -5, 0);
            vektoren[2] = new Vektor(-1, 2, -3);

            double[] skalar = new double[3] { 3, -5, 1 };

            Vektor[] vektorenErgebnis = new Vektor[3];
            vektorenErgebnis[0] = new Vektor(0.333333333, 0.6666666666, 1);
            vektorenErgebnis[1] = new Vektor(0, 1, 0);
            vektorenErgebnis[2] = new Vektor(-1, 2, -3);

            for (int i = 0; i < vektoren.Length; i++)
            {
                Vektor vektorDivDurchSkalar = VektorFunktionen.DivisionDurchSkalar(vektoren[i], skalar[i]);
                bool result = (String.Format("{0:f5}", vektorDivDurchSkalar.XKoord) == String.Format("{0:f5}", vektorenErgebnis[i].XKoord))
                                && (String.Format("{0:f5}", vektorDivDurchSkalar.YKoord) == String.Format("{0:f5}", vektorenErgebnis[i].YKoord))
                                && (String.Format("{0:f5}", vektorDivDurchSkalar.ZKoord) == String.Format("{0:f5}", vektorenErgebnis[i].ZKoord));
                String word = "xyz";
                Assert.IsTrue(result, String.Format("Expected for '{0}': true; Actual: {1}", word, result));
            }
        }


        [TestMethod]
        public void TestMethodSkalarprodukt()
        {
            Vektor[] vektorenFaktor1 = new Vektor[3];
            vektorenFaktor1[0] = new Vektor(1.23456, 2, 3);
            vektorenFaktor1[1] = new Vektor(0, 0, 0);
            vektorenFaktor1[2] = new Vektor(-1, 2, -3);

            Vektor[] vektorenFaktor2 = new Vektor[3];
            vektorenFaktor2[0] = new Vektor(-5.123456, 2, 3);
            vektorenFaktor2[1] = new Vektor(4, -1, -5);
            vektorenFaktor2[2] = new Vektor(1, -2, 3);

            double[] skalarProdukt = new double[3] { 6.67478616064, 0, -14 };

            for (int i = 0; i < vektorenFaktor1.Length; i++)
            {
                double skalarProd = VektorFunktionen.Skalarprodukt(vektorenFaktor1[i], vektorenFaktor2[i]);
                bool result = (String.Format("{0:f5}", skalarProd) == String.Format("{0:f5}", skalarProdukt[i]));
                String word = "xyz";
                Assert.IsTrue(result, String.Format("Expected for '{0}': true; Actual: {1}", word, result));
            }
        }

        [TestMethod]
        public void TestMethodKreuzprodukt()
        {
            Vektor[] vektoren1 = new Vektor[3];
            vektoren1[0] = new Vektor(1.23456, 2, 3);
            vektoren1[1] = new Vektor(0, 0, 0);
            vektoren1[2] = new Vektor(-1, 2, -3);

            Vektor[] vektoren2 = new Vektor[3];
            vektoren2[0] = new Vektor(-5.123456, 2, 3);
            vektoren2[1] = new Vektor(4, -1, -5);
            vektoren2[2] = new Vektor(1, -2, 3);

            Vektor[] vektorenKreuzprodukt = new Vektor[3];
            vektorenKreuzprodukt[0] = new Vektor(0, -19.074048, 12.716032);
            vektorenKreuzprodukt[1] = new Vektor(0, 0, 0);
            vektorenKreuzprodukt[2] = new Vektor(0, 0, 0);

            for (int i = 0; i < vektoren1.Length; i++)
            {
                Vektor kreuzProd = VektorFunktionen.Kreuzprodukt(vektoren1[i], vektoren2[i]);
                bool result = (String.Format("{0:f5}", kreuzProd.XKoord) == String.Format("{0:f5}", vektorenKreuzprodukt[i].XKoord))
                                && (String.Format("{0:f5}", kreuzProd.YKoord) == String.Format("{0:f5}", vektorenKreuzprodukt[i].YKoord))
                                && (String.Format("{0:f5}", kreuzProd.ZKoord) == String.Format("{0:f5}", vektorenKreuzprodukt[i].ZKoord));
                String word = "xyz";
                Assert.IsTrue(result, String.Format("Expected for '{0}': true; Actual: {1}", word, result));
            }
        }


        [TestMethod]
        public void TestMethodLaengeBerechnen()
        {
            Vektor[] vektoren = new Vektor[3];
            vektoren[0] = new Vektor(1, 2, 3);
            vektoren[1] = new Vektor(0, -5, 0);
            vektoren[2] = new Vektor(-1, 2, -3);

            double[] laenge = new double[3] { 3.74165738677394, 5, 3.74165738677394 };
            
            for (int i = 0; i < vektoren.Length; i++)
            {
                double laeng = VektorFunktionen.LaengeBerechnen(vektoren[i]);
                bool result = (String.Format("{0:f5}",laeng) == String.Format("{0:f5}", laenge[i]));
                String word = "xyz";
                Assert.IsTrue(result, String.Format("Expected for '{0}': true; Actual: {1}", word, result));
            }
        }

        [TestMethod]
        public void TestMethodWinkelZw2Vektoren()
        {
            Vektor[] vektoren1 = new Vektor[3];
            vektoren1[0] = new Vektor(1, 0, 0);
            vektoren1[1] = new Vektor(0, 1, 0);
            vektoren1[2] = new Vektor(1, 2, 3);

            Vektor[] vektoren2 = new Vektor[3];
            vektoren2[0] = new Vektor(0, 1, 0);
            vektoren2[1] = new Vektor(0, -1, 0);
            vektoren2[2] = new Vektor(-5, 2, 3);

            double[] winkel = new double[3] { 90, 180, 69.70559965222 };

            for (int i = 0; i < vektoren1.Length; i++)
            {
                double winkl = VektorFunktionen.WinkelZw2Vektoren(vektoren1[i], vektoren2[i]);

                bool result = (String.Format("{0:f5}", winkl) == String.Format("{0:f5}", winkel[i]));
                Console.WriteLine("winkl: " + winkl);
                Console.WriteLine("winkel[i]: " + winkel[i]);
                Console.WriteLine("i: " + i + " result" + result);
                String word = "xyz";
                Assert.IsTrue(result, String.Format("Expected for '{0}': true; Actual: {1}", word, result));
            }

        }


        [TestMethod]
        public void TestMethodVektorenWertegleich()
        {
            Vektor[] vektoren1 = new Vektor[3];
            vektoren1[0] = new Vektor(1.333, 2, 3);
            vektoren1[1] = new Vektor(0, 0, 0);
            vektoren1[2] = new Vektor(-1, (2/3), -3.5);

            Vektor[] vektoren2 = new Vektor[3];
            vektoren2[0] = new Vektor(1.333, 2, 3);
            vektoren2[1] = new Vektor(0, 0, 0);
            vektoren2[2] = new Vektor(-1, (2/3), -3.5);

            for (int i = 0; i < vektoren1.Length; i++)
            {
                bool result = VektorFunktionen.VektorenWertgleich(vektoren1[i], vektoren2[i]);
                String word = "xyz";
                Assert.IsTrue(result, String.Format("Expected for '{0}': true; Actual: {1}", word, result));
            }
        }     
    }
}
