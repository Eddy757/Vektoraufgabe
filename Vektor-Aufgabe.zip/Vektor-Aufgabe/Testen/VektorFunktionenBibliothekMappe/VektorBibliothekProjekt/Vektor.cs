﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VektorBibliothekProjekt
{   
    public class Vektor
    {
        private double xKoord = 0;
        private double yKoord = 0;
        private double zKoord = 0;

        public Vektor(double xKoord, double yKoord, double zKoord)
        {
            // hier einen Eingabecheck einbauen? Falls ungültige Eingabe usw
            this.xKoord = xKoord;
            this.yKoord = yKoord;
            this.zKoord = zKoord;
        }

        public double XKoord
        {
            get { return xKoord; }
            set
            {
                // hier einen Check einbauen?
                xKoord = value;
            }
        }

        public double YKoord
        {
            get { return yKoord; }
            set
            {
                // hier einen Check einbauen?
                yKoord = value;
            }
        }

        public double ZKoord
        {
            get { return zKoord; }
            set
            {
                // hier einen Check einbauen?
                zKoord = value;
            }
        }
    }
}