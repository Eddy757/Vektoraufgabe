﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace VektorBibliothekProjekt
{
    public static class VektorFunktionen
    {


        /// <summary>
        /// Es wird ein Vektor invertiert
        /// </summary>
        /// <param name="vektor">Vektor, der invertiert werden soll</param>
        /// <returns>Rueckgabe des invertierten Vektors als neues Vektor-Objekt</returns>
        public static Vektor Invertieren(Vektor vektor)
        {
            Vektor vektorInvert = new Vektor(0, 0, 0);
            vektorInvert.XKoord = vektor.XKoord * (-1);
            vektorInvert.YKoord = vektor.YKoord * (-1);
            vektorInvert.ZKoord = vektor.ZKoord * (-1);
            return vektorInvert;

        }


        /// <summary>
        /// Zwei Vektoren werden miteinander addiert
        /// </summary>
        /// <param name="vektor1">Summand-Vektor1</param>
        /// <param name="vektor2">Summand-Vektor2</param>
        /// <returns>Rueckgabe des Summenvektors als neues Vektor-Objekt</returns>
        public static Vektor Addition(Vektor vektor1, Vektor vektor2)
        {
            Vektor vektorSumme = new Vektor(0, 0, 0);
            vektorSumme.XKoord = vektor1.XKoord + vektor2.XKoord;
            vektorSumme.YKoord = vektor1.YKoord + vektor2.YKoord;
            vektorSumme.ZKoord = vektor1.ZKoord + vektor2.ZKoord;
            return vektorSumme;
        }


        /// <summary>
        /// Es findet eine Vektorsubtraktion statt
        /// </summary>
        /// <param name="vektor1">Minuend-Vektor</param>
        /// <param name="vektor2">Subtrahend-Vektor</param>
        /// <returns>Rueckgabe des Differenzvektors als neues Vektor-Objekt</returns>
        public static Vektor Subtraktion(Vektor vektor1, Vektor vektor2)
        {
            Vektor vektorSumme = new Vektor(0, 0, 0);
            vektorSumme.XKoord = vektor1.XKoord - vektor2.XKoord;
            vektorSumme.YKoord = vektor1.YKoord - vektor2.YKoord;
            vektorSumme.ZKoord = vektor1.ZKoord - vektor2.ZKoord;
            return vektorSumme;
        }


        /// <summary>
        /// Ein Vektor wird mit einem Skalar mulitpliziert
        /// </summary>
        /// <param name="vektor">Der zu mulitiplizierende Vektor</param>
        /// <param name="skalar">Skalar</param>
        /// <returns>Rueckgabe des Erbebnisses der Multiplikation als neues Vektor-Objekt</returns>
        public static Vektor MultiplMitSkalar(Vektor vektor, double skalar)
        {
            Vektor vektorMultMitSkalar = new Vektor(0, 0, 0);
            vektorMultMitSkalar.XKoord = vektor.XKoord * skalar;
            vektorMultMitSkalar.YKoord = vektor.YKoord * skalar;
            vektorMultMitSkalar.ZKoord = vektor.ZKoord * skalar;
            return vektorMultMitSkalar;
        }


        /// <summary>
        /// Division eines Vektors durch einen Skalar
        /// </summary>
        /// <param name="vektor">Der betreffende Vektor</param>
        /// <param name="skalar">Skalar</param>
        /// <returns>Rueckgabe des Erbebnisses der Multiplikation als neues Objekt</returns>
        public static Vektor DivisionDurchSkalar(Vektor vektor, double skalar)
        {
            Vektor vektorDivisionDurchSkalar = new Vektor(0, 0, 0);
            vektorDivisionDurchSkalar.XKoord = vektor.XKoord / skalar;
            vektorDivisionDurchSkalar.YKoord = vektor.YKoord / skalar;
            vektorDivisionDurchSkalar.ZKoord = vektor.ZKoord / skalar;
            return vektorDivisionDurchSkalar;
        }


        /// <summary>
        /// Berechnung des Skalarprodukts zweier Vektoren, Vektor1 und Vektor2
        /// </summary>
        /// <param name="vektor1">Vektor1</param>
        /// <param name="vektor2">Vektor2</param>
        /// <returns>Rueckgabe des Skalarprodukts als double</returns>
        public static double Skalarprodukt(Vektor vektor1, Vektor vektor2)
        {
            double skalarprodukt = vektor1.XKoord * vektor2.XKoord + vektor1.YKoord * vektor2.YKoord + vektor1.ZKoord * vektor2.ZKoord;
            return skalarprodukt;
        }


        /// <summary>
        /// Berechnung des Kreuzprodukts zweier Vektoren, Vektor1 und Vektor2
        /// </summary>
        /// <param name="vektor1">Vektor1</param>
        /// <param name="vektor2">Vektor2</param>
        /// <returns>Rueckgabe des Kreuprodukts als neues Objekt</returns>
        public static Vektor Kreuzprodukt(Vektor vektor1, Vektor vektor2)
        {
            Vektor kreuzprodukt = new Vektor(0, 0, 0);
            kreuzprodukt.XKoord = vektor1.YKoord * vektor2.ZKoord - vektor1.ZKoord * vektor2.YKoord;
            kreuzprodukt.YKoord = vektor1.ZKoord * vektor2.XKoord - vektor1.XKoord * vektor2.ZKoord;
            kreuzprodukt.ZKoord = vektor1.XKoord * vektor2.YKoord - vektor1.YKoord * vektor2.XKoord;
            return kreuzprodukt;
        }


        /// <summary>
        /// Berechnung von Laenge/Betrag eines Vektors
        /// </summary>
        /// <param name="vektor">der betreffende Vektor</param>
        /// <returns>Reuckgabe von Laenge/Betrags des Vektors als double</returns>
        public static double LaengeBerechnen(Vektor vektor)
        {
            double laenge = 0;
            laenge = Math.Sqrt(vektor.XKoord * vektor.XKoord + vektor.YKoord * vektor.YKoord + vektor.ZKoord * vektor.ZKoord);
            return laenge;
        }


        /// <summary>
        /// Berechnung des Winkels zwischen zwei Vektoren, Vektor1 und Vektor1
        /// </summary>
        /// <param name="vektor1">Vektor1</param>
        /// <param name="vektor2">Vektor2</param>
        /// <returns>Rueckgabe des Winkels in gradmass als double </returns>
        public static double WinkelZw2Vektoren(Vektor vektor1, Vektor vektor2)
        {
            double winkel_bogenmaß = 0;
            double winkel_gradmaß = 0;
            winkel_bogenmaß = Math.Acos(Skalarprodukt(vektor1, vektor2) / (LaengeBerechnen(vektor1) * LaengeBerechnen(vektor2)));
            winkel_gradmaß = winkel_bogenmaß * 360 / (2 * Math.PI);
            return winkel_gradmaß;
        }


        /// <summary>
        /// Es wird verglichen, ob zwei Vektoren (Vektor1 und Vektor2) dieselben Koordinaten besitzen
        /// </summary>
        /// <param name="vektor1">Vektor1</param>
        /// <param name="vektor2">Vektor2</param>
        /// <returns>Rueckgabe eines True-Wertes bei Wertegleichheit, sonst False</returns>
        public static bool VektorenWertgleich(Vektor vektor1, Vektor vektor2)
        {

            if (vektor1.XKoord == vektor2.XKoord && vektor1.YKoord == vektor2.YKoord && vektor1.ZKoord == vektor2.ZKoord)
            {
                Console.WriteLine("Die Vektoren sind INHALTLICH gleich");
                return true;
            }
            else return false;
        }


        public static void AusgabeBildschirm(Vektor vektor)
        {
            Console.WriteLine();
            Console.WriteLine(vektor.XKoord);
            Console.WriteLine(vektor.YKoord);
            Console.WriteLine(vektor.ZKoord);
            //Console.WriteLine("Laenge: " + vektor.Laenge);
            //Console.WriteLine("Laenge: " + vektor.Laenge);
            //Console.WriteLine("Laenge: " + LaengeBerechnen(vektor));

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
        }

    }
}