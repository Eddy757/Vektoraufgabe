﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VektorBibliothekProjekt;

namespace WpfApp1
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Beim Klick auf den Rechen_Button wird das Kreuzprodukt aus den vorgegebenen Vektoren Vektor1 und Vektor2 berechnet
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                // hier Ueberprung der Eingabe notwedig! Leere Eingaben, falsche Eingaben
                Vektor vektor1 = new Vektor(Convert.ToDouble(TextboxVektor1X.Text), Convert.ToDouble(TextboxVektor1Y.Text), Convert.ToDouble(TextboxVektor1Z.Text));
                Vektor vektor2 = new Vektor(Convert.ToDouble(TextboxVektor2X.Text), Convert.ToDouble(TextboxVektor2Y.Text), Convert.ToDouble(TextboxVektor2Z.Text));

                Vektor vektorKreuzProd = new Vektor(0, 0, 0);
                vektorKreuzProd = VektorFunktionen.Kreuzprodukt(vektor1, vektor2);

                LabelKreuzprodX.Content = String.Format("{0:f3}", vektorKreuzProd.XKoord);
                LabelKreuzprodY.Content = String.Format("{0:f3}", vektorKreuzProd.YKoord);
                LabelKreuzprodZ.Content = String.Format("{0:f3}", vektorKreuzProd.ZKoord);
            }
            catch(Exception)
            {
                MessageBox.Show("Bitte geben Sie gueltige Werte ein!");
            }
        }



        /// <summary>
        /// Beim Klick auf den Reset-Button werden alle Werte von Vektor1, Vektor2 und Krezuprodukt-Vektor gelöscht
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            LabelKreuzprodX.Content = "";
            LabelKreuzprodY.Content = "";
            LabelKreuzprodZ.Content = "";

            TextboxVektor1X.Text = "";
            TextboxVektor1Y.Text = "";
            TextboxVektor1Z.Text = "";

            TextboxVektor2X.Text = "";
            TextboxVektor2Y.Text = "";
            TextboxVektor2Z.Text = "";
        }
    }
}
